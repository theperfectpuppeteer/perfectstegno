(() => {
  const norm = value => value.toUpperCase().replace(/[^A-Z0-9]/g, '');
  // FNV-1a hashes keep casual answer spoilers out of the visible page markup.
  // This is a puzzle gate, not real authentication; a determined visitor can inspect client-side code.
  const hash = value => {
    let h = 0x811c9dc5;
    for (let i = 0; i < value.length; i++) {
      h ^= value.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h.toString(16).padStart(8, '0');
  };
  document.querySelectorAll('[data-gate]').forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const input = form.querySelector('input');
      const feedback = form.parentElement.querySelector('.feedback');
      const unlocked = form.parentElement.querySelector('.unlocked');
      if (hash(norm(input.value)) === form.dataset.answerHash) {
        feedback.textContent = 'SIGNAL ACCEPTED. THE ARCHIVE HAS REMEMBERED.';
        feedback.style.color = 'var(--success)';
        unlocked.classList.add('show');
        input.value = '';
        input.disabled = true;
        form.querySelector('button').disabled = true;
        form.querySelector('button').textContent = 'ACCEPTED';
      } else {
        feedback.textContent = 'NO MATCH. SOMETHING IN THE SIGNAL IS STILL UNREAD.';
        feedback.style.color = 'var(--warn)';
        input.focus();
      }
    });
  });
})();
