# ILLUSIONARY // ARCHIVE 001

A self-contained, static, six-page puzzle experience.

Open `index.html` to begin. Each stage contains an encoded transmission and a phrase gate. The recovered message reveals the next page.

No build tools are required. Upload the HTML files and `assets/` folder to a static web host.
